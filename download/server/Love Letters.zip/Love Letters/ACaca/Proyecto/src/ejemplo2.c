#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include "utils.h"


/*void waitFor (unsigned int secs) {
    unsigned int retTime = time(0) + secs;   // Get finishing time.
    while (time(0) < retTime);               // Loop until it arrives.
}*/

static const int width= 1024;
static const int height= 768;


void draw_random_points(int nr_points, bool randomizeColor, SDL_Renderer *renderer) {

    for (int i=0; i<nr_points; i++) {
        
        if(randomizeColor) {
            SDL_SetRenderDrawColor(renderer, randomColor(), randomColor(), randomColor(), 255);
        }
        SDL_RenderDrawPoint(renderer, randomNumber(0, width), randomNumber(0, height));
    }
}

void draw_random_lines(int nr_lines, bool randomizeColor, SDL_Renderer *renderer) {

    for (int i=0; i<nr_lines; i++) {
        
        if(randomizeColor) {
            SDL_SetRenderDrawColor(renderer, randomColor(), randomColor(), randomColor(), 255);
        }
        SDL_RenderDrawLine(renderer, randomNumber(0, width), randomNumber(0, height), randomNumber(0, width), randomNumber(0, height));
    }
} 

int main(int argc, char* argv[]) {

    //SLD INICIAR
    SDL_Init(SDL_INIT_VIDEO);

    //SDL INICIAR WINDOW
    SDL_Window *window= SDL_CreateWindow("Wena qlo", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_OPENGL);

    //Renderer
    SDL_Renderer *renderer= SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    //SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
        
    

    //SDL_Delay(2000);
    bool running = true;//Para que corra hasta que el usuario lo cierre
    SDL_Event event;
    while(running) {

        //Procesar eventos
        while(SDL_PollEvent(&event)) {
            if (event.type== SDL_QUIT) {
                running = false;
            }
        }
        //Clear screen
         SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
         SDL_RenderClear(renderer);
        //Draw
         SDL_SetRenderDrawColor(renderer, 255,255,0,255);
         draw_random_points(500, false, renderer);
         draw_random_lines(500, false, renderer);

         SDL_SetRenderDrawColor(renderer, 255,randomNumber(0,255),randomNumber(0,255),randomNumber(0,255));
         SDL_Rect rect= {50, 50, 600, 200};
         SDL_RenderFillRect(renderer, &rect);

         SDL_SetRenderDrawColor(renderer, randomNumber(0,255),randomNumber(0,255),255,255);
         SDL_Rect rect2= {250, 300, 200, 250};
         SDL_RenderDrawRect(renderer, &rect2);

        //Show what was drawn
        SDL_RenderPresent(renderer);
    }

    //SOLTAR RECURSOS
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();




return 0;
}
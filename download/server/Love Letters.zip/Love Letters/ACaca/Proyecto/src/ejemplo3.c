#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include "utils.h"

static const int width= 1024;
static const int height= 768;
SDL_Rect tamCarta;

int main(int argc, char* argv[]) {

    //SLD INICIAR
    SDL_Init(SDL_INIT_VIDEO);

    //SDL INICIAR WINDOW
    SDL_Window *window= SDL_CreateWindow("Wena qlo", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_OPENGL);

    //Renderer
    //https://wiki.libsdl.org/SDL_CreateWindow?highlight=%28%5CbCategoryVideo%5Cb%29%7C%28CategoryEnum%29%7C%28CategoryStruct%29
    SDL_Renderer *renderer= SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    SDL_Surface *background= SDL_LoadBMP("table background.bmp"); 
         if(background == NULL) {
        
         SDL_ShowSimpleMessageBox(0, "Background init error", SDL_GetError(), window);
         }
    SDL_Texture *fondo= SDL_CreateTextureFromSurface(renderer, background);
    //SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
    //SDL_ShowSimpleMessageBox(0, "Background init error", SDL_GetError(), window); VENTANA DE ERROR, SIRVE
    
    
    //SDL_Delay(2000);
    bool running = true;//Para que corra hasta que el usuario lo cierre
    SDL_Event event;
    while(running){

        
        //Procesar eventos
        while(SDL_PollEvent(&event)) {
            if (event.type== SDL_QUIT) {
                running = false;
            }
        }
        //Clear screen
         SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
         SDL_RenderClear(renderer);
        //Draw
         //SDL_SetRenderDrawColor(renderer, 255,255,255,255);
         //SDL_RenderCopy(renderer, fondo, NULL, NULL);
         //SDL_RenderPresent(renderer);
        ImagenEnUbic(&tamCarta, 200, 200, 100, 100);
        SDL_RenderFillRect(renderer, &tamCarta);
        SDL_RenderCopy(renderer, fondo, NULL, &tamCarta);
        
        /*
        tamCarta.x= 200;
        tamCarta.y= 200;
        tamCarta.w= 100;
        tamCarta.h= 100;
        SDL_RenderFillRect(renderer, &tamCarta);
        SDL_RenderCopy(renderer, fondo, NULL, &tamCarta);
        */
        //Show what was drawn
        SDL_RenderPresent(renderer);
    }

    //SOLTAR RECURSOS
    SDL_DestroyTexture(background);
    SDL_FreeSurface(fondo);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();




return 0;
}
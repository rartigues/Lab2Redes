#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include "utils.h"

static const int width= 1024;
static const int height= 768;


int main(int argc, char* argv[]) {

    //SLD INICIAR
    SDL_Init(SDL_INIT_VIDEO);

    //SDL INICIAR WINDOW
    SDL_Window *window= SDL_CreateWindow("Wena qlo", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_OPENGL);

    //Renderer
    //https://wiki.libsdl.org/SDL_CreateWindow?highlight=%28%5CbCategoryVideo%5Cb%29%7C%28CategoryEnum%29%7C%28CategoryStruct%29
    SDL_Renderer *renderer= SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    SDL_Surface *background= SDL_LoadBMP("table background.bmp"); 
    SDL_Surface *background2= SDL_LoadBMP("sebaaa.bmp");
    SDL_Surface *background3= SDL_LoadBMP("encerrao.bmp");
    SDL_Texture *fondo= SDL_CreateTextureFromSurface(renderer, background);
    SDL_Texture *fondo2= SDL_CreateTextureFromSurface(renderer, background2);
    SDL_Texture *fondo3= SDL_CreateTextureFromSurface(renderer, background3);
    SDL_Texture *current= fondo;
         /*if(background == NULL) {
        
         SDL_ShowSimpleMessageBox(0, "Background init error", SDL_GetError(), window);
         }*/
    
    //SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
    //SDL_ShowSimpleMessageBox(0, "Background init error", SDL_GetError(), window); VENTANA DE ERROR, SIRVE
    
    
    //SDL_Delay(2000);
    bool running = true;//Para que corra hasta que el usuario lo cierre
    SDL_Event event;
    int eval=0;
    while(running){

        
        //Procesar eventos
        while(SDL_PollEvent(&event)) {
            
            if (event.type== SDL_QUIT) {
                
                running = false;
            } else if (event.type== SDL_KEYDOWN) {
                
                switch (event.key.keysym.sym)
                {
                case SDLK_1:
                    current= fondo;
                    break;
                
                case SDLK_2:
                    current= fondo2;
                    break;

                case SDLK_3:
                    current= fondo3;
                    break;
                
                }

            }
        }
        //Clear screen
        SDL_RenderClear(renderer);
        
        //Draw
        SDL_RenderCopy (renderer, current, NULL, NULL);
        
         
         
        //Show what was drawn
        SDL_RenderPresent(renderer);
        
    }

    //SOLTAR RECURSOS
    SDL_DestroyTexture(background);
    SDL_DestroyTexture(background2);
    SDL_DestroyTexture(background3);
    SDL_DestroyTexture(current);
    SDL_FreeSurface(fondo);
    SDL_FreeSurface(fondo2);
    SDL_FreeSurface(fondo3);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();




return 0;
}
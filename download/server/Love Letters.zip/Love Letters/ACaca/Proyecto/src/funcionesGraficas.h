#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include "funcionesCelulas.h"

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 620;

SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;
TTF_Font *font = NULL;

void renderizarCelula(int estadoActual, int posX, int posY){

  SDL_Rect dibujoCelula;
  dibujoCelula.h = 20;
  dibujoCelula.w = 20;
  dibujoCelula.x = posX * 20;
  dibujoCelula.y = posY * 20;
  if(estadoActual){
    SDL_SetRenderDrawColor(renderer, 248, 243, 53, 255);
    SDL_RenderFillRect(renderer, &dibujoCelula);
    SDL_SetRenderDrawColor(renderer, 156, 156, 156, 255);
    SDL_RenderDrawRect(renderer, &dibujoCelula);
  }
  else{
    SDL_SetRenderDrawColor(renderer, 130, 130, 130, 255);
    SDL_RenderFillRect(renderer, &dibujoCelula);
    SDL_SetRenderDrawColor(renderer, 156, 156, 156, 255);
    SDL_RenderDrawRect(renderer, &dibujoCelula);
  }

}

void renderizarBoton(int numBoton){

  SDL_Texture *boton = NULL;
  SDL_Surface *botonCargado = NULL;
  SDL_Rect tamBoton;
  SDL_SetRenderDrawColor(renderer, 156, 156, 156, 255);
  if(numBoton == 1){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/playButton.png");
    if(botonCargado == NULL){
		  printf("Unable to load play button! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create play button SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 40;
    tamBoton.y = 582
    tamBoton.w = 36;
    tamBoton.h = 36;
    SDL_RenderFillRect(renderer, &tamBoton);
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  if(numBoton == 2){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/pauseButton.png");
    if(botonCargado == NULL){
		  printf("Unable to load pause button! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create pause button! SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 40;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
    SDL_RenderFillRect(renderer, &tamBoton);
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  if(numBoton == 3){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/stepButton.png");
    if(botonCargado == NULL){
		  printf("Unable to load step button! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create step button! SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 110;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  if(numBoton == 4){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/resetButton.png");
    if(botonCargado == NULL){
		  printf("Unable to load reset button! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create reset button! SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 645;
    tamBoton.y = 582;
    tamBoton.w = 32;
    tamBoton.h = 36;
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  if(numBoton == 5){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/speedIcon.png");
    if(botonCargado == NULL){
		  printf("Unable to load speed icon! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create speed icon! SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 380;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  if(numBoton == 6){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/minusButton.png");
    if(botonCargado == NULL){
		  printf("Unable to load minus button! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create minus button! SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 330;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  if(numBoton == 7){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/plusButton.png");
    if(botonCargado == NULL){
		  printf("Unable to load plus button! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create plus button! SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 430;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  if(numBoton == 8){
    botonCargado = IMG_Load("C:/Users/sebastian/desktop/programas/Proyecto Programacion 1/Iconos/presetButton.png");
    if(botonCargado == NULL){
		  printf("Unable to load preset button! SDL_image Error: %s\n", IMG_GetError());
	  }
    else{
      boton = SDL_CreateTextureFromSurface(renderer, botonCargado);
      if(boton == NULL){
        printf("Unable to create preset button! SDL Error: %s\n", SDL_GetError());
		  }
    }
    tamBoton.x = 580;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
    SDL_RenderCopy(renderer, boton, NULL, &tamBoton);
  }
  SDL_FreeSurface(botonCargado);
  SDL_DestroyTexture(boton);
  
}

void quitarBoton(int numBoton){

  SDL_Rect tamBoton;
  SDL_SetRenderDrawColor(renderer, 156, 156, 156, 255);
  if(numBoton == 1){
    tamBoton.x = 330;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
  }
  else{
    tamBoton.x = 430;
    tamBoton.y = 582;
    tamBoton.w = 36;
    tamBoton.h = 36;
  }
  SDL_RenderFillRect(renderer, &tamBoton);

}

void renderizarNum(int num, int esContadorCelulas){

  char sNum[12];
  sprintf(sNum, "%d", num);
  int digitos;
  for(digitos = 1; num > 0; ++digitos){    
    num /= 10;
  }
  font = TTF_OpenFont("C:/Windows/Fonts/arial.ttf", 30); 
  SDL_Color textColor = {0, 0, 0}; 
  SDL_Surface *surfaceMessage;
  SDL_Texture *Message;
  SDL_Rect Message_rect; 
  Message_rect.w = 20;
  Message_rect.h = 18;
  if(!esContadorCelulas){
    Message_rect.x = 715;
    Message_rect.y = 582;
    surfaceMessage = TTF_RenderText_Solid(font, "G:", textColor);
    Message = SDL_CreateTextureFromSurface(renderer, surfaceMessage);
  }
  else{
    Message_rect.x = 715;
    Message_rect.y = 600;
    surfaceMessage = TTF_RenderText_Solid(font, "C:", textColor);
    Message = SDL_CreateTextureFromSurface(renderer, surfaceMessage);
  }
  SDL_RenderCopy(renderer, Message, NULL, &Message_rect);
  Message_rect.x = 742;
  Message_rect.w = 8 * digitos;
  SDL_SetRenderDrawColor(renderer, 156, 156, 156, 255);
  SDL_RenderFillRect(renderer, &Message_rect);
  surfaceMessage = TTF_RenderText_Solid(font, sNum, textColor);
  Message = SDL_CreateTextureFromSurface(renderer, surfaceMessage);
  SDL_RenderCopy(renderer, Message, NULL, &Message_rect);
  SDL_FreeSurface(surfaceMessage);
  SDL_DestroyTexture(Message);

}
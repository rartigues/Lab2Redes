#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include "utils.h"


//Generate a random number
int randomNumber(int nr_min, int nr_max) {

    static bool initialized = false;
    if(!initialized) {
        
        initialized= true;
        srand(time(NULL));
    }
    return rand()% nr_max+nr_min;
}

int randomColor() {

    return randomNumber(0,255);
}
/*
void ImagenEnUbic(SDL_Renderer *renderer, SDL_Texture *Imagen, SDL_Rect tam, int x, int y, int w, int h) {

    tam.x= x;
    tam.y= y;
    tam.w= w;
    tam.h= h;
    SDL_RenderFillRect(renderer, &tam);
    SDL_RenderCopy(renderer, Imagen, NULL, &tam);
}
*/


/*void draw_random_lines(int nr_lines, bool randomizeColor, SDL_Renderer *renderer) {

    for (int i=0; i<nr_lines; i++) {
        
        if(randomizeColor) {
            SDL_SetRenderDrawColor(renderer, randomColor(), randomColor(), randomColor(), 255);
        }
        SDL_RenderDrawLine(renderer, randomNumber(0, width), randomNumber(0, height), randomNumber(0, width), randomNumber(0, height));
    }
}

void draw_random_points(int nr_points, bool randomizeColor, SDL_Renderer *renderer) {

    for (int i=0; i<nr_points; i++) {
        
        if(randomizeColor) {
            SDL_SetRenderDrawColor(renderer, randomColor(), randomColor(), randomColor(), 255);
        }
        SDL_RenderDrawPoint(renderer, randomNumber(0, width), randomNumber(0, height));
    }
}*/

void waitFor (unsigned int secs) {
    unsigned int retTime = time(0) + secs;   // Get finishing time.
    while (time(0) < retTime);               // Loop until it arrives.
}


/*#include <stdlib.h>
#include <time.h>
#include <stdbool.h>*/
#ifndef UTILS
#define UTILS

//Generate a random number
int randomNumber(int nr_min, int nr_max);

int randomColor();

//void ImagenEnUbic(SDL_Renderer *renderer, SDL_Texture *Imagen, SDL_Rect tam, int x, int y, int w, int h);

void ImagenEnUbic(SDL_Rect *tam, int x, int y, int w, int h) {

    tam->x= x;
    tam->y= y;
    tam->w= w;
    tam->h= h;
}

/*void draw_random_lines(int nr_lines, bool randomizeColor, SDL_Renderer *renderer) {

    for (int i=0; i<nr_lines; i++) {
        
        if(randomizeColor) {
            SDL_SetRenderDrawColor(renderer, randomColor(), randomColor(), randomColor(), 255);
        }
        SDL_RenderDrawLine(renderer, randomNumber(0, width), randomNumber(0, height), randomNumber(0, width), randomNumber(0, height));
    }
}

void draw_random_points(int nr_points, bool randomizeColor, SDL_Renderer *renderer) {

    for (int i=0; i<nr_points; i++) {
        
        if(randomizeColor) {
            SDL_SetRenderDrawColor(renderer, randomColor(), randomColor(), randomColor(), 255);
        }
        SDL_RenderDrawPoint(renderer, randomNumber(0, width), randomNumber(0, height));
    }
}*/

void waitFor (unsigned int secs);

#endif
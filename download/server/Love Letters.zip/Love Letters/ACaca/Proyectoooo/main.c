#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#include "cartas.h" 
#include "reglas.h"

int main(){
    srand(time(NULL));
    ////reemplazar por SDL
    int numeroDeJugadores;
    scanf("%d", &numeroDeJugadores);
    /////////////////
    Mazo* mazo;
    mazo = crearMazo(mazo);
    Jugador* jugadores;
    switch (numeroDeJugadores){
    case 2:
        jugadores = crearJugadores(2);
        while (jugadores->tokens != 7 || (jugadores+1)->tokens != 7){
            primerTurno(mazo,jugadores,2);
            do{
                    
            }while (cuantasquedan);
        }
        break;
    
    default:
        break;
    }

    printf("\n");
    return 0;
}
    #include "./Bin/reglas.h"

static const int width= 1366;
static const int height= 768;

int main(int argc, char* argv[]) {


    //SLD INICIAR
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();

    //SDL INICIAR WINDOW
    SDL_Window *window= SDL_CreateWindow("Love Letters", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_OPENGL);
    SDL_Surface *icon= SDL_LoadBMP("./Source/icon.bmp");
    SDL_SetWindowIcon (window, icon);

    //Renderer
    SDL_Renderer *renderer= SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    SDL_Surface *MenuPrincipalSurf= SDL_LoadBMP("./Source/menuprincipal.bmp"); 
    SDL_Texture *MenuPrincipalTex= SDL_CreateTextureFromSurface(renderer, MenuPrincipalSurf);
    //
    SDL_Surface *MenuPrincipalReglasSurf= SDL_LoadBMP("./Source/menuprincipalreglas.bmp");
    SDL_Texture *MenuPrincipalReglasTex= SDL_CreateTextureFromSurface(renderer, MenuPrincipalReglasSurf);
    //
    SDL_Surface *CntosJugadoresSurf= SDL_LoadBMP("./Source/cntosjugadores.bmp");
    SDL_Texture *CntosJugadoresTex= SDL_CreateTextureFromSurface(renderer, CntosJugadoresSurf);
    //
    SDL_Surface *MenuPrimerJugadorSurf= SDL_LoadBMP("./Source/primerjugador.bmp");
    SDL_Texture *MenuPrimerJugadorTex= SDL_CreateTextureFromSurface(renderer, MenuPrimerJugadorSurf);
    //
    SDL_Surface *PrimerJugador1Surf= SDL_LoadBMP("./Source/primerjugador1.bmp");
    SDL_Texture *PrimerJugador1Tex= SDL_CreateTextureFromSurface(renderer, PrimerJugador1Surf);
    //
    SDL_Surface *PrimerJugador2Surf= SDL_LoadBMP("./Source/primerjugador2.bmp");
    SDL_Texture *PrimerJugador2Tex= SDL_CreateTextureFromSurface(renderer, PrimerJugador2Surf);
    //
    SDL_Surface *PrimerJugador3Surf= SDL_LoadBMP("./Source/primerjugador3.bmp");
    SDL_Texture *PrimerJugador3Tex= SDL_CreateTextureFromSurface(renderer, PrimerJugador3Surf);
    //
    SDL_Surface *PrimerJugador4Surf= SDL_LoadBMP("./Source/primerjugador4.bmp");
    SDL_Texture *PrimerJugador4Tex= SDL_CreateTextureFromSurface(renderer, PrimerJugador4Surf);
    //
    SDL_Surface *MenuDeJuegoSurf= SDL_LoadBMP("./Source/menudejuego.bmp");
    SDL_Texture *MenuDeJuegoTex= SDL_CreateTextureFromSurface(renderer, MenuDeJuegoSurf);
    //
    SDL_Surface *AyudaCartas1Surf= SDL_LoadBMP("./Source/ayudacartas1.bmp");
    SDL_Texture *AyudaCartas1Tex= SDL_CreateTextureFromSurface(renderer, AyudaCartas1Surf);
    //
    SDL_Surface *AyudaCartas2Surf= SDL_LoadBMP("./Source/ayudacartas2.bmp");
    SDL_Texture *AyudaCartas2Tex= SDL_CreateTextureFromSurface(renderer, AyudaCartas2Surf);
    //
    SDL_Surface *MenuManoSurf= SDL_LoadBMP ("./Source/menumano.bmp");
    SDL_Texture *MenuManoTex= SDL_CreateTextureFromSurface(renderer, MenuManoSurf);
    //
    SDL_Surface *MenuManoSeleccionSurf= SDL_LoadBMP ("./Source/menumanoseleccion.bmp");
    SDL_Texture *MenuManoSeleccionTex= SDL_CreateTextureFromSurface(renderer, MenuManoSeleccionSurf);
    //
    SDL_Surface *MenuGuardianSurf= SDL_LoadBMP ("./Source/menuguardian1.bmp");
    SDL_Texture *MenuGuardianTex= SDL_CreateTextureFromSurface(renderer, MenuGuardianSurf);
    //
    SDL_Surface *MenuZonaDescarteSurf= SDL_LoadBMP ("./Source/menuzonadescarte.bmp");
    SDL_Texture *MenuZonaDescarteTex= SDL_CreateTextureFromSurface(renderer, MenuZonaDescarteSurf);
    //
    SDL_Surface *MenuGanadorRondaSurf= SDL_LoadBMP ("./Source/menuganadorronda.bmp");
    SDL_Texture *MenuGanadorRondaTex= SDL_CreateTextureFromSurface(renderer, MenuGanadorRondaSurf);
    //
    SDL_Surface *MenuGanadorPartidaSurf= SDL_LoadBMP ("./Source/menuganadorpartida.bmp");
    SDL_Texture *MenuGanadorPartidaTex= SDL_CreateTextureFromSurface(renderer, MenuGanadorPartidaSurf);
    //
    SDL_Surface *BotonJugador1Surf= SDL_LoadBMP ("./Source/botonjugador1.bmp");
    SDL_Texture *BotonJugador1Tex= SDL_CreateTextureFromSurface(renderer, BotonJugador1Surf);
    //
    SDL_Surface *BotonJugador2Surf= SDL_LoadBMP ("./Source/botonjugador2.bmp");
    SDL_Texture *BotonJugador2Tex= SDL_CreateTextureFromSurface(renderer, BotonJugador2Surf);
    //
    SDL_Surface *BotonJugador3Surf= SDL_LoadBMP ("./Source/botonjugador3.bmp");
    SDL_Texture *BotonJugador3Tex= SDL_CreateTextureFromSurface(renderer, BotonJugador3Surf);
    //
    SDL_Surface *BotonJugador4Surf= SDL_LoadBMP ("./Source/botonjugador4.bmp");
    SDL_Texture *BotonJugador4Tex= SDL_CreateTextureFromSurface(renderer, BotonJugador4Surf);
    //
    SDL_Texture *actual= MenuPrincipalTex;


    
    CartaGuardiaSurf= SDL_LoadBMP("./Source/Cartas/guardian.bmp");
    CartaGuardiaTex= SDL_CreateTextureFromSurface(renderer, CartaGuardiaSurf);
    //
    CartaSacerdoteSurf= SDL_LoadBMP("./Source/Cartas/sacerdote.bmp");
    CartaSacerdoteTex= SDL_CreateTextureFromSurface(renderer, CartaSacerdoteSurf);
    //
    CartaBaronSurf= SDL_LoadBMP("./Source/Cartas/baron.bmp");
    CartaBaronTex= SDL_CreateTextureFromSurface(renderer, CartaBaronSurf); 
    //
    CartaDoncellaSurf= SDL_LoadBMP("./Source/Cartas/doncella.bmp");
    CartaDoncellaTex= SDL_CreateTextureFromSurface(renderer, CartaDoncellaSurf);
    //
    CartaPrincipeSurf= SDL_LoadBMP("./Source/Cartas/principe.bmp");
    CartaPrincipeTex= SDL_CreateTextureFromSurface(renderer, CartaPrincipeSurf);
    //
    CartaReySurf= SDL_LoadBMP("./Source/Cartas/rey.bmp");
    CartaReyTex= SDL_CreateTextureFromSurface(renderer, CartaReySurf);
    //
    CartaCondesaSurf= SDL_LoadBMP("./Source/Cartas/condesa.bmp");
    CartaCondesaTex= SDL_CreateTextureFromSurface(renderer, CartaCondesaSurf);
    //
    CartaPrincesaSurf= SDL_LoadBMP("./Source/Cartas/princesa.bmp");
    CartaPrincesaTex= SDL_CreateTextureFromSurface(renderer, CartaPrincesaSurf);
    //
    CartaDetrasSurf= SDL_LoadBMP("./Source/Cartas/cartadetras.bmp");
    CartaDetrasTex= SDL_CreateTextureFromSurface(renderer, CartaDetrasSurf);
    //
    

    
    //Prep Colocar cartas donde se necesite
    SDL_Texture* CartaActual1= CartaDetrasTex;
    SDL_Texture* CartaActual2= CartaDetrasTex;
    SDL_Rect tamCarta;
    
    

    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    srand(time(NULL));
    Mazo* mazo;
    Jugador* jugadores;
    //funcionamiento del juego
    int pantalla= 0, tb=-5, tb2=-5, nJugadores=0,desabilitado = 0,jugadorRestante=-1;
    //variables para el uso de cartas
    int jugadorSeleccionado = -1,cartaUsada = 0,cartaSeleccionada = 0,aux = 0;
    valorMayor ganador;
    //pantalla es para las fondos
    //auxturno es para ver si se sigue en el mismo turno o si paso al siguiente
    //desabilitado es para cumplir la condicion de la condesa
    //jugadadoresRestantes es para ver cuantos jugadores siguen en la ronda
    //nuevojuego es para ver si se comenzo una nueva partida y para ver si todavia nadie consigue los tokens para ganar
    //valormayor es para ver la carta de mayor valor de los jugadores restantes cuando se acaba el mazo
    //jugadorSeleccionado, es para guardar que jugador seleccionado al usar una carta
    //cartaUsada es para guardar que carta uso
    // los jugadores asignan 

    //Font
    TTF_Font *font= TTF_OpenFont("./Source/KaushanScript-Regular.ttf", 70); 
    SDL_Color color= {63, 34, 23, 255}; //255,204,229=Rosado   255,204,153=Cafe
    SDL_Surface *textSurface= TTF_RenderText_Solid(font, "Placeholder", color);
    
    //jugadores+jugadorActual)->tokens) 
    textSurface= TTF_RenderText_Solid(font, "0", color);
    SDL_Texture *T0= SDL_CreateTextureFromSurface(renderer, textSurface);

    textSurface= TTF_RenderText_Solid(font, "1", color);
    SDL_Texture *T1= SDL_CreateTextureFromSurface(renderer, textSurface);

    textSurface= TTF_RenderText_Solid(font, "2", color);
    SDL_Texture *T2= SDL_CreateTextureFromSurface(renderer, textSurface);

    textSurface= TTF_RenderText_Solid(font, "3", color);
    SDL_Texture *T3= SDL_CreateTextureFromSurface(renderer, textSurface);

    textSurface= TTF_RenderText_Solid(font, "4", color);
    SDL_Texture *T4= SDL_CreateTextureFromSurface(renderer, textSurface);

    textSurface= TTF_RenderText_Solid(font, "5", color);
    SDL_Texture *T5= SDL_CreateTextureFromSurface(renderer, textSurface);

    textSurface= TTF_RenderText_Solid(font, "6", color);
    SDL_Texture *T6= SDL_CreateTextureFromSurface(renderer, textSurface);

    textSurface= TTF_RenderText_Solid(font, "7", color);
    SDL_Texture *T7= SDL_CreateTextureFromSurface(renderer, textSurface);
    



    //int textW=0, textH=0;
    //SDL_QueryTexture(text, NULL, NULL, &textW, &textH);
    //SDL_Rect dstrect= {500,600, textW, textH};



    bool running= true;
    bool nuevoTurno = true;
    bool nuevoJuego = true;
    bool mazoVacio = false;
    //Para que corra hasta que el usuario lo cierre
    SDL_Event event;
    while(running){
        //Procesar eventos
        while(SDL_PollEvent(&event)) {
            
            if (event.type== SDL_QUIT) {
                
                running= false;
            }
            else if (event.type== SDL_KEYDOWN){
                if (event.key.keysym.sym== SDLK_ESCAPE && tb!=-5) {pantalla=tb; tb=-5;} //Volver al ultimo menu
                if (event.key.keysym.sym== SDLK_BACKSPACE) {pantalla=0; limpiarMemoria(mazo,jugadores,nJugadores);}//Volver menu principal
                if (event.key.keysym.sym== SDLK_F1) {if(pantalla!=-1&&pantalla!=-2 && tb!=3)tb=pantalla; pantalla=-1;} //Abrir el menu de cartas y volver al previo
                if (event.key.keysym.sym== SDLK_F2) {if(pantalla!=-1&&pantalla!=-2 && tb!=3)tb=pantalla; pantalla=-2;}
            }   
        }

        //Clear screen
        SDL_SetRenderDrawColor(renderer, 209, 153, 126, 255);
        SDL_RenderClear(renderer);

        //Draw
        SDL_RenderCopy (renderer, actual, NULL, NULL);
        switch (pantalla) {
            case -4:
                actual = MenuPrimerJugadorTex;
                switch (nJugadores){
                case 4:
                    ImagenEnUbic(&tamCarta, 554, 663, 259, 57);
                    SDL_RenderFillRect(renderer, &tamCarta);
                    SDL_RenderCopy(renderer, PrimerJugador4Tex, NULL, &tamCarta);
                    if (event.type== SDL_MOUSEBUTTONDOWN) if (event.button.x>=553 && event.button.x<=812 && event.button.y>=663 && event.button.y<=719) {jugadorActual = 2;pantalla = 2;}
                case 3:
                    ImagenEnUbic(&tamCarta, 554, 588, 259, 57);
                    SDL_RenderFillRect(renderer, &tamCarta);
                    SDL_RenderCopy(renderer, PrimerJugador3Tex, NULL, &tamCarta);
                    if (event.type== SDL_MOUSEBUTTONDOWN) if (event.button.x>=553 && event.button.x<=812 && event.button.y>=588 && event.button.y<=644) {jugadorActual = 1; pantalla= 2;}
                default:
                    ImagenEnUbic(&tamCarta, 554, 513, 259, 57);
                    SDL_RenderFillRect(renderer, &tamCarta);
                    SDL_RenderCopy(renderer, PrimerJugador2Tex, NULL, &tamCarta);
                    ImagenEnUbic(&tamCarta, 554, 438, 259, 57);
                    SDL_RenderFillRect(renderer, &tamCarta);
                    SDL_RenderCopy(renderer, PrimerJugador1Tex, NULL, &tamCarta);
                    if (event.type== SDL_MOUSEBUTTONDOWN) {
                        if (event.button.x>=554 && event.button.x<=812 && event.button.y>=513 && event.button.y<=569) {jugadorActual = 0; pantalla=2;}
                        if (event.button.x>=553 && event.button.x<=812 && event.button.y>=438 && event.button.y<=494) {jugadorActual = -1; pantalla=2;}
                    break;
                    }
                }
                break;

            case -3: //MenuPrincipalReglas
                actual= MenuPrincipalReglasTex;
                if (event.type== SDL_MOUSEBUTTONDOWN) {
                    if (event.button.x>=553 && event.button.x<=812 && event.button.y>=468 && event.button.y<=525) pantalla= 1;
                    if (event.button.x>=553 && event.button.x<=812 && event.button.y>=569 && event.button.y<=627) running= false;
                }
                break;
            case -2: //Cartas2
                actual= AyudaCartas2Tex;
                break;

            case -1: //Cartas1
                actual=AyudaCartas1Tex;
                break;

            case 0: //Menu Principal 
                actual=MenuPrincipalTex;
                if (event.type== SDL_MOUSEBUTTONDOWN) {
                    if (event.button.x>=553 && event.button.x<=812 && event.button.y>=468 && event.button.y<=525) pantalla=1;
                    if (event.button.x>=553 && event.button.x<=812 && event.button.y>=569 && event.button.y<=627) running= false;
                    if (event.button.x>=12 && event.button.x<=151 && event.button.y>=702 && event.button.y<=755) pantalla=-3;
                }
                break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            case 1: //Seleccion Jugadores //LISTO
                actual=CntosJugadoresTex;
                if (event.type== SDL_MOUSEBUTTONDOWN) {
                    if (event.button.x>=553 && event.button.x<=812 && event.button.y>=300 && event.button.y<=356) {nJugadores= 2; waitFor(1); pantalla= -4;}
                    if (event.button.x>=553 && event.button.x<=812 && event.button.y>=412 && event.button.y<=468) {nJugadores= 3; waitFor(1); pantalla= -4;}
                    if (event.button.x>=553 && event.button.x<=812 && event.button.y>=524 && event.button.y<=580) {nJugadores= 4; waitFor(1); pantalla= -4;}
                }
                break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            case 2://MenuDeJuego //NUMERO DE TOKEN
                actual=MenuDeJuegoTex;
                if (nuevoJuego){
                    jugadores = crearJugadores(nJugadores);
                    mazo = crearMazo(mazo); 
                    primerTurno(mazo,jugadores,nJugadores);
                    nuevoJuego = false;
                }
            
                if (nuevoTurno){  
                    do{
                        jugadorActual++;
                        if (jugadorActual == nJugadores) jugadorActual = 0;
                    }while ((jugadores+jugadorActual)->participa == false);
                    if (cuantasQuedan == 0) mazoVacio = true;
                    jugadorRestante = ultimoJugador(jugadores,nJugadores);
                    if (mazoVacio || jugadorRestante != -1){
                        pantalla = 10;
                        break;
                    }
                    (jugadores+jugadorActual)->inmunidad = false;
                    cartaSeleccionada = 0;
                    jugadorSeleccionado = -1;
                    cartaUsada = 0;    
                    robarCarta(mazo,jugadores,jugadorActual); 
                    nuevoTurno = false;
                }
                ImagenEnUbic(&tamCarta, 18, 19, 295, 45); //Renderizar el jugador actual
                
                switch (jugadorActual){
                    
                case 0:
                    SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);
                    break;
                case 1:
                    SDL_RenderCopy(renderer, BotonJugador2Tex, NULL, &tamCarta);
                    break;
                case 2:
                    SDL_RenderCopy(renderer, BotonJugador3Tex, NULL, &tamCarta);
                    break;
                case 3:
                    SDL_RenderCopy(renderer, BotonJugador4Tex, NULL, &tamCarta);
                    break;
                default:
                    break;
                }
                ImagenEnUbic(&tamCarta, 316, 15, 42, 56); //Renderizar cantidad de tokens del jugador
                SDL_RenderFillRect(renderer, &tamCarta);
                switch((jugadores+jugadorActual)->tokens) {
                    case 0:
                        SDL_RenderCopy(renderer, T0, NULL, &tamCarta);
                        break;
                    case 1:
                        SDL_RenderCopy(renderer, T1, NULL, &tamCarta);
                        break;
                    case 2:
                        SDL_RenderCopy(renderer, T2, NULL, &tamCarta);
                        break;
                    case 3:
                        SDL_RenderCopy(renderer, T3, NULL, &tamCarta);
                        break;
                    case 4:
                        SDL_RenderCopy(renderer, T4, NULL, &tamCarta);
                        break;
                    case 5:
                        SDL_RenderCopy(renderer, T5, NULL, &tamCarta);
                        break;
                    case 6:
                        SDL_RenderCopy(renderer, T6, NULL, &tamCarta);
                        break;
                    case 7:
                        SDL_RenderCopy(renderer, T7, NULL, &tamCarta);
                        break;
                    default:
                        break;
                }
                    
                
                if (event.type== SDL_MOUSEBUTTONDOWN) {
                    if (event.button.x>=1045 && event.button.x<=1339 && event.button.y>=70 && event.button.y<=126) pantalla=3;
                    if (event.button.x>=1045 && event.button.x<=1339 && event.button.y>=155 && event.button.y<=212) {tb= 2; pantalla= 8;}
                }
                break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////       
            case 3: //Menu Ver Mano
                
                actual=MenuManoTex;
                CartaActual1 = cargarCarta((jugadores+jugadorActual)->cartasMano[0].valor,&tamCarta, 96, 127, 363, 499);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                CartaActual2 = cargarCarta((jugadores+jugadorActual)->cartasMano[1].valor,&tamCarta,573, 127, 363, 499);
                //ImagenEnUbic(&tamCarta, 573, 127, 363, 499);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual2, NULL, &tamCarta);

                ImagenEnUbic(&tamCarta, 18, 19, 295, 45); //Renderizar el jugador actual
                
                switch (jugadorActual){
                    
                case 0:
                    SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);
                    break;
                case 1:
                    SDL_RenderCopy(renderer, BotonJugador2Tex, NULL, &tamCarta);
                    break;
                case 2:
                    SDL_RenderCopy(renderer, BotonJugador3Tex, NULL, &tamCarta);
                    break;
                case 3:
                    SDL_RenderCopy(renderer, BotonJugador4Tex, NULL, &tamCarta);
                    break;
                default:
                    break;
                }
                ImagenEnUbic(&tamCarta, 316, 15, 42, 56); //Renderizar cantidad de tokens del jugador
                SDL_RenderFillRect(renderer, &tamCarta);
                switch((jugadores+jugadorActual)->tokens) {
                    case 0:
                        SDL_RenderCopy(renderer, T0, NULL, &tamCarta);
                        break;
                    case 1:
                        SDL_RenderCopy(renderer, T1, NULL, &tamCarta);
                        break;
                    case 2:
                        SDL_RenderCopy(renderer, T2, NULL, &tamCarta);
                        break;
                    case 3:
                        SDL_RenderCopy(renderer, T3, NULL, &tamCarta);
                        break;
                    case 4:
                        SDL_RenderCopy(renderer, T4, NULL, &tamCarta);
                        break;
                    case 5:
                        SDL_RenderCopy(renderer, T5, NULL, &tamCarta);
                        break;
                    case 6:
                        SDL_RenderCopy(renderer, T6, NULL, &tamCarta);
                        break;
                    case 7:
                        SDL_RenderCopy(renderer, T7, NULL, &tamCarta);
                        break;
                    default:
                        break;
                }


                if (event.type== SDL_MOUSEBUTTONDOWN) {
                    if (event.button.x>=1045 && event.button.x<=1339 && event.button.y>=155 && event.button.y<=212) {tb= 3; pantalla= 8;}
                }

                //comprobar cartas
                if ((jugadores+jugadorActual)->cartasMano[0].valor == 7) {if ((jugadores+jugadorActual)->cartasMano[1].valor == 5 || (jugadores+jugadorActual)->cartasMano[1].valor == 6) desabilitado = 2;}
                else if ((jugadores+jugadorActual)->cartasMano[1].valor == 7) {if ((jugadores+jugadorActual)->cartasMano[0].valor == 5 || (jugadores+jugadorActual)->cartasMano[0].valor == 6) desabilitado = 1;}
            
                if (event.type== SDL_MOUSEBUTTONDOWN && desabilitado!= 1) if (event.button.x>=96 && event.button.x<=459 && event.button.y>=127 && event.button.y<=626) {
                    cartaUsada = (jugadores+jugadorActual)->cartasMano[0].valor;
                    pantalla = usarCarta(jugadores,0,(jugadores+jugadorActual)->cartasMano[0].valor);
                    waitFor(1);
                    
                } //PRESIONO PRIMERA CARTA
                if (event.type== SDL_MOUSEBUTTONDOWN && desabilitado!= 2) if (event.button.x>=573 && event.button.x<=935 && event.button.y>=127 && event.button.y<=626) {
                    cartaUsada = (jugadores+jugadorActual)->cartasMano[1].valor;
                    pantalla = usarCarta(jugadores,1,(jugadores+jugadorActual)->cartasMano[1].valor);
                    waitFor(1);
                } //PRESIONO SEGUNDA CARTA
                desabilitado = 0;
                nuevoTurno = true;
                if (cartaUsada == 4 || cartaUsada == 7 || cartaUsada == 8) pantalla = 2;
                break;
            
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////            
            case 4: //MenuSeleccionarJugador //DEBE FUNCIONAR CON TODAS LAS CARTAS QUE SELECCIONEN JUGADOR (GUARDIAN, SACERDOTE, BARON, PRINCIPE, REY)
                actual= MenuManoSeleccionTex;
                CartaActual1 = cargarCarta((jugadores+jugadorActual)->cartasMano[0].valor,&tamCarta,  96, 127, 363, 499);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                ImagenEnUbic(&tamCarta, 18, 19, 295, 45); //Renderizar el jugador actual
                SDL_RenderFillRect(renderer, &tamCarta);
                switch (jugadorActual){
                    
                case 0:
                    SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);
                    break;
                case 1:
                    SDL_RenderCopy(renderer, BotonJugador2Tex, NULL, &tamCarta);
                    break;
                case 2:
                    SDL_RenderCopy(renderer, BotonJugador3Tex, NULL, &tamCarta);
                    break;
                case 3:
                    SDL_RenderCopy(renderer, BotonJugador4Tex, NULL, &tamCarta);
                    break;
                default:
                    break;
                }
                ImagenEnUbic(&tamCarta, 316, 15, 42, 56); //Renderizar cantidad de tokens del jugador
                SDL_RenderFillRect(renderer, &tamCarta);
                switch((jugadores+jugadorActual)->tokens) {
                    case 0:
                        SDL_RenderCopy(renderer, T0, NULL, &tamCarta);
                        break;
                    case 1:
                        SDL_RenderCopy(renderer, T1, NULL, &tamCarta);
                        break;
                    case 2:
                        SDL_RenderCopy(renderer, T2, NULL, &tamCarta);
                        break;
                    case 3:
                        SDL_RenderCopy(renderer, T3, NULL, &tamCarta);
                        break;
                    case 4:
                        SDL_RenderCopy(renderer, T4, NULL, &tamCarta);
                        break;
                    case 5:
                        SDL_RenderCopy(renderer, T5, NULL, &tamCarta);
                        break;
                    case 6:
                        SDL_RenderCopy(renderer, T6, NULL, &tamCarta);
                        break;
                    case 7:
                        SDL_RenderCopy(renderer, T7, NULL, &tamCarta);
                        break;
                    default:
                        break;
                }
                
                //ELEGIR JUGADOR
                if (jugadorSeleccionado== -1) {
                    switch(nJugadores){
                        case 4:
                            if((jugadores+3)->inmunidad==false) {
                                ImagenEnUbic(&tamCarta, 1045, 671, 295, 45);
                                SDL_RenderFillRect(renderer, &tamCarta);
                                SDL_RenderCopy(renderer, BotonJugador4Tex, NULL, &tamCarta);
                            }
                        case 3:
                            if((jugadores+2)->inmunidad==false) {
                                ImagenEnUbic(&tamCarta, 1045, 611, 295, 45);
                                SDL_RenderFillRect(renderer, &tamCarta);
                                SDL_RenderCopy(renderer, BotonJugador3Tex, NULL, &tamCarta);
                            }   
                        case 2:
                            if((jugadores+1)->inmunidad==false) {
                                ImagenEnUbic(&tamCarta, 1045, 550, 295, 45);
                                SDL_RenderFillRect(renderer, &tamCarta);
                                SDL_RenderCopy(renderer, BotonJugador2Tex, NULL, &tamCarta);
                            }                               
                        default:
                            if((jugadores+0)->inmunidad==false) {
                                ImagenEnUbic(&tamCarta, 1045, 490, 295, 45);
                                SDL_RenderFillRect(renderer, &tamCarta);
                                SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);
                            }
                        break;
                    }
                    if (event.type== SDL_MOUSEBUTTONDOWN) {
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=484 && event.button.y<=540 && nJugadores>=2 && (jugadores)->inmunidad == false) {waitFor(1); jugadorSeleccionado = 0;}
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=544 && event.button.y<=600 && nJugadores>=2 && (jugadores+1)->inmunidad == false) {waitFor(1); jugadorSeleccionado = 1;}
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=605 && event.button.y<=661 && nJugadores>=3 && (jugadores+2)->inmunidad == false) {waitFor(1); jugadorSeleccionado = 2;}    
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=665 && event.button.y<=721 && nJugadores>=4 && (jugadores+3)->inmunidad == false) {waitFor(1); jugadorSeleccionado = 3;}
                    }    
                }
                //EFECTO DE LA CARTA USADA
                else{
                    switch (cartaUsada){
                        case 1: pantalla = 5;
                            break;
                        case 2: pantalla = 6;
                            break;
                        case 3: 
                            if ((jugadores+jugadorActual)->cartasMano[0].valor == (jugadores+jugadorSeleccionado)->cartasMano[0].valor) {
                                pantalla = 6;
                                break;}
                            else if ((jugadores+jugadorActual)->cartasMano[0].valor > (jugadores+jugadorSeleccionado)->cartasMano[0].valor) {
                                (jugadores+jugadorSeleccionado)->participa = false;
                                (jugadores+jugadorSeleccionado)->inmunidad= true;
                            }
                            else{ 
                                (jugadores+jugadorActual)->participa = false;
                                (jugadores+jugadorSeleccionado)->inmunidad= true;
                            }
                            pantalla = 6;
                            break;
                        case 5:
                            if (mazoVacio == false){
                                (jugadores+jugadorSeleccionado)->numDescartadas++;
                                (jugadores+jugadorSeleccionado)->manoDescartada[(jugadores+jugadorSeleccionado)->numDescartadas-1].valor = (jugadores+jugadorSeleccionado)->cartasMano[0].valor;
                                if ((jugadores+jugadorSeleccionado)->cartasMano[0].valor == 8){
                                    (jugadores+jugadorSeleccionado)->participa = false;
                                    (jugadores+jugadorSeleccionado)->inmunidad = true;  
                                }
                                else robarCarta(mazo,jugadores+jugadorSeleccionado,jugadorSeleccionado);
                            }
                            else{
                                (jugadores+jugadorSeleccionado)->numDescartadas++;
                                (jugadores+jugadorSeleccionado)->manoDescartada[(jugadores+jugadorSeleccionado)->numDescartadas-1].valor = (jugadores+jugadorSeleccionado)->cartasMano[0].valor;
                                (jugadores+jugadorSeleccionado)->participa = false;
                                (jugadores+jugadorSeleccionado)->inmunidad= true;
                            } 
                            pantalla = 2;
                            break;
                        case 6: 
                            aux = (jugadores+jugadorActual)->cartasMano[0].valor;
                            (jugadores+jugadorActual)->cartasMano[0].valor = (jugadores+jugadorSeleccionado)->cartasMano[0].valor;
                            (jugadores+jugadorSeleccionado)->cartasMano[0].valor = aux;
                            pantalla = 2;
                            break;
                        default:
                            //tirar error
                            break;
                    }
                }
                break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            case 5: //MenuGuardianSeleccionarCarta
                actual= MenuGuardianTex;
                CartaActual1 = cargarCarta((jugadores+jugadorActual)->cartasMano[0].valor,&tamCarta,  96, 127, 363, 499);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                ImagenEnUbic(&tamCarta, 96, 127, 363, 499);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                ImagenEnUbic(&tamCarta, 18, 19, 295, 45); //Renderizar el jugador actual
                
                switch (jugadorActual){
                    
                case 0:
                    SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);
                    break;
                case 1:
                    SDL_RenderCopy(renderer, BotonJugador2Tex, NULL, &tamCarta);
                    break;
                case 2:
                    SDL_RenderCopy(renderer, BotonJugador3Tex, NULL, &tamCarta);
                    break;
                case 3:
                    SDL_RenderCopy(renderer, BotonJugador4Tex, NULL, &tamCarta);
                    break;
                default:
                    break;
                }
                ImagenEnUbic(&tamCarta, 316, 15, 42, 56); //Renderizar cantidad de tokens del jugador
                SDL_RenderFillRect(renderer, &tamCarta);
                switch((jugadores+jugadorActual)->tokens) {
                    case 0:
                        SDL_RenderCopy(renderer, T0, NULL, &tamCarta);
                        break;
                    case 1:
                        SDL_RenderCopy(renderer, T1, NULL, &tamCarta);
                        break;
                    case 2:
                        SDL_RenderCopy(renderer, T2, NULL, &tamCarta);
                        break;
                    case 3:
                        SDL_RenderCopy(renderer, T3, NULL, &tamCarta);
                        break;
                    case 4:
                        SDL_RenderCopy(renderer, T4, NULL, &tamCarta);
                        break;
                    case 5:
                        SDL_RenderCopy(renderer, T5, NULL, &tamCarta);
                        break;
                    case 6:
                        SDL_RenderCopy(renderer, T6, NULL, &tamCarta);
                        break;
                    case 7:
                        SDL_RenderCopy(renderer, T7, NULL, &tamCarta);
                        break;
                    default:
                        break;
                }
                
                if (cartaSeleccionada == 0){
                    if (event.type== SDL_MOUSEBUTTONDOWN) {//*******BUG******
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=492 && event.button.y<=517) cartaSeleccionada = 2; //SACERDOTE
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=524 && event.button.y<=549) cartaSeleccionada = 3; //Baron
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=556 && event.button.y<=581) cartaSeleccionada = 4; //Doncella
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=588 && event.button.y<=614) cartaSeleccionada = 5; //Principe
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=620 && event.button.y<=645) cartaSeleccionada = 6; //Rey
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=652 && event.button.y<=677) cartaSeleccionada = 7; //Condesa
                        if (event.button.x>=1046 && event.button.x<=1339 && event.button.y>=684 && event.button.y<=710) cartaSeleccionada = 8; //Princesa
                    
                        if ((jugadores+jugadorSeleccionado)->cartasMano[0].valor == cartaSeleccionada) {
                            (jugadores+jugadorSeleccionado)->participa = false;
                            (jugadores+jugadorSeleccionado)->inmunidad = true;
                        }
                    }
                }
                else pantalla = 6;
                break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            case 6:

                actual=MenuManoSeleccionTex;
                
                ImagenEnUbic(&tamCarta, 18, 19, 295, 45); //Renderizar el jugador actual
                
                switch (jugadorActual){
                    
                case 0:
                    SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);
                    break;
                case 1:
                    SDL_RenderCopy(renderer, BotonJugador2Tex, NULL, &tamCarta);
                    break;
                case 2:
                    SDL_RenderCopy(renderer, BotonJugador3Tex, NULL, &tamCarta);
                    break;
                case 3:
                    SDL_RenderCopy(renderer, BotonJugador4Tex, NULL, &tamCarta);
                    break;
                default:
                    break;
                }
                ImagenEnUbic(&tamCarta, 316, 15, 42, 56); //Renderizar cantidad de tokens del jugador
                SDL_RenderFillRect(renderer, &tamCarta);
                switch((jugadores+jugadorActual)->tokens) {
                    case 0:
                        SDL_RenderCopy(renderer, T0, NULL, &tamCarta);
                        break;
                    case 1:
                        SDL_RenderCopy(renderer, T1, NULL, &tamCarta);
                        break;
                    case 2:
                        SDL_RenderCopy(renderer, T2, NULL, &tamCarta);
                        break;
                    case 3:
                        SDL_RenderCopy(renderer, T3, NULL, &tamCarta);
                        break;
                    case 4:
                        SDL_RenderCopy(renderer, T4, NULL, &tamCarta);
                        break;
                    case 5:
                        SDL_RenderCopy(renderer, T5, NULL, &tamCarta);
                        break;
                    case 6:
                        SDL_RenderCopy(renderer, T6, NULL, &tamCarta);
                        break;
                    case 7:
                        SDL_RenderCopy(renderer, T7, NULL, &tamCarta);
                        break;
                    default:
                        break;
                }
                
                
                //MOSTRAR CARTA
                    switch (cartaUsada){
                        case 1: //Guardia, mostrar la tuya y la que tenia
                            CartaActual1 = cargarCarta(cartaSeleccionada,&tamCarta, 96, 127, 363, 499);
                            SDL_RenderFillRect(renderer, &tamCarta);
                            SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                            
                            CartaActual2 = cargarCarta((jugadores+jugadorSeleccionado)->cartasMano[0].valor,&tamCarta, 573, 127, 363, 499);
                            SDL_RenderFillRect(renderer, &tamCarta);
                            SDL_RenderCopy(renderer, CartaActual2, NULL, &tamCarta);
                            
                            break;
                        case 2: //Sacedote, mostrar carta del jugador que uno elige
                            CartaActual1 = cargarCarta((jugadores+jugadorSeleccionado)->cartasMano[0].valor,&tamCarta, 96, 127, 363, 499);
                            SDL_RenderFillRect(renderer, &tamCarta);
                            SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                            
                            CartaActual2 = cargarCarta(0,&tamCarta, 573, 127, 363, 499);
                            SDL_RenderFillRect(renderer, &tamCarta);
                            SDL_RenderCopy(renderer, CartaActual2, NULL, &tamCarta);
                            
                            break;
                        case 3: //Baron, la tuya y la del jugador, *****y compararla****
                            CartaActual1 = cargarCarta((jugadores+jugadorActual)->cartasMano[0].valor,&tamCarta, 96, 127, 363, 499);
                            SDL_RenderFillRect(renderer, &tamCarta);
                            SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                            
                            
                            CartaActual2 = cargarCarta((jugadores+jugadorSeleccionado)->cartasMano[0].valor,&tamCarta, 573, 127, 363, 499);
                            SDL_RenderFillRect(renderer, &tamCarta);
                            SDL_RenderCopy(renderer, CartaActual2, NULL, &tamCarta);
                            
                            break;
                        default:
                            SDL_ShowSimpleMessageBox(0, "COMO MIERDA LLEGASTE AL DEFAULT CTM", SDL_GetError(), window);
                            break;
                    }
                //waitFor(2);
                if (event.type== SDL_MOUSEBUTTONDOWN) if ((event.button.x<=1044 && event.button.y>=0) || (event.button.x<=1366 && (event.button.y<=483||event.button.y>=722))) {waitFor(1); pantalla = 2;}
            
                break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            case 8: //ZonaDescarte
                actual=MenuZonaDescarteTex;
                //UbicacionParaElSpawnDeCartas//
                //************jugadores1**************
                CartaActual1 = cargarCarta((jugadores)->manoDescartada[0].valor,&tamCarta, 38, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);

                CartaActual1 = cargarCarta((jugadores)->manoDescartada[1].valor,&tamCarta, 137, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores)->manoDescartada[2].valor,&tamCarta, 236, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores)->manoDescartada[3].valor,&tamCarta, 38, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores)->manoDescartada[4].valor,&tamCarta, 137, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores)->manoDescartada[5].valor,&tamCarta, 236, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores)->manoDescartada[6].valor,&tamCarta, 73, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores)->manoDescartada[7].valor,&tamCarta, 194, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
            
                //**************jugadores2************
                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[0].valor,&tamCarta, 372, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);

                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[1].valor,&tamCarta, 471, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[2].valor,&tamCarta, 570, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[3].valor,&tamCarta, 372, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[4].valor,&tamCarta, 471, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[5].valor,&tamCarta, 570, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[6].valor,&tamCarta, 407, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+1)->manoDescartada[7].valor,&tamCarta, 528, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                //**********jugadores3************
                if (nJugadores>=3) {
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[0].valor,&tamCarta, 706, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[1].valor,&tamCarta, 805, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[2].valor,&tamCarta, 904, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[3].valor,&tamCarta, 706, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[4].valor,&tamCarta, 805, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[5].valor,&tamCarta, 904, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[6].valor,&tamCarta, 741, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+2)->manoDescartada[7].valor,&tamCarta, 862, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                }
                //********jugadores4********
                if (nJugadores==4) {
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[0].valor,&tamCarta, 1040, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[1].valor,&tamCarta, 1139, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[2].valor,&tamCarta, 1238, 40, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[3].valor,&tamCarta, 1040, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[4].valor,&tamCarta, 1139, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[5].valor,&tamCarta, 1238, 201, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[6].valor,&tamCarta, 1075, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                
                CartaActual1 = cargarCarta((jugadores+3)->manoDescartada[7].valor,&tamCarta, 1196, 362, 98, 136);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                }

                //DEFAULTBOTADAS
                CartaActual1 = cargarCarta(0,&tamCarta, 299, 556, 145, 202);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                if (nJugadores == 2){
                CartaActual1 = cargarCarta(mazo->mazoDescartado[1].valor,&tamCarta, 508, 556, 145, 202);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                //
                CartaActual1 = cargarCarta(mazo->mazoDescartado[2].valor,&tamCarta, 719, 556, 145, 202);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                //
                CartaActual1 = cargarCarta(mazo->mazoDescartado[3].valor,&tamCarta, 930, 556, 145, 202);
                SDL_RenderFillRect(renderer, &tamCarta);
                SDL_RenderCopy(renderer, CartaActual1, NULL, &tamCarta);
                }

                break;

    

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            case 10://ganador ronda
            actual=MenuGanadorRondaTex;
            ImagenEnUbic(&tamCarta, 535,232,295,45);
            SDL_RenderFillRect(renderer, &tamCarta);
            
            
            if (mazoVacio){
                valorMayor ganador;
                jugadorMasalto(&ganador,jugadores,nJugadores);
                for (int i = 0;i < nJugadores;i++){
                    if (ganador.sumadevalores[i] != 0) {
                        (jugadores+i)->tokens++;
                        jugadorRestante = (jugadores+i)->player;    
                    }
                }
            }

            switch(jugadorRestante) {
                case 0:
                    SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);
                    break;
                case 1:
                    SDL_RenderCopy(renderer, BotonJugador2Tex, NULL, &tamCarta);
                    break;
                case 2:
                    SDL_RenderCopy(renderer, BotonJugador3Tex, NULL, &tamCarta);
                    break;
                case 3:
                    SDL_RenderCopy(renderer, BotonJugador4Tex, NULL, &tamCarta);
                    break;
                default:
                    break;  
            }
            if (event.type== SDL_MOUSEBUTTONDOWN) {
                if (event.button.x>=611 && event.button.x<=754 && event.button.y>=554 && event.button.y<=596){
                    free(mazo);
                    mazo = crearMazo();
                    nuevoTurno = true;
                    primerTurno(mazo,jugadores,nJugadores);
                    if (mazoVacio == false) (jugadores+jugadorRestante)->tokens++;        
                    jugadorActual = jugadorRestante-1;
                    pantalla = 2;
                    for (int i = 0;i < nJugadores;i++){
                        switch (nJugadores){
                            case 2:
                                if((jugadores+i)->tokens == 7) pantalla = 11;
                                break;
                            case 3:
                                if((jugadores+i)->tokens == 5) pantalla = 11;
                                break;
                            case 4:
                                if((jugadores+i)->tokens == 4) pantalla = 11;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            //SDL_RenderCopy(renderer, BotonJugador1Tex, NULL, &tamCarta);            
            break;

            case 11:
                actual=MenuGanadorPartidaTex;
                waitFor(1);
                if (event.type== SDL_MOUSEBUTTONDOWN) if (event.button.x>=611 && event.button.x<=754 && event.button.y>=554 && event.button.y<=596) {  waitFor(1); pantalla = 0;limpiarMemoria(mazo,jugadores,nJugadores);}  
                break;          
            default:
            SDL_ShowSimpleMessageBox(0, "ERROR CAMBIO DE PANTALLA", SDL_GetError(), window);
                break;
        }
        
        
        
        //SDL_RenderCopy (renderer, text, NULL, &dstrect); Texto
        //Show what was drawn
        SDL_RenderPresent(renderer);
        SDL_UpdateWindowSurface(window);
        //if (pantalla == 6)
            //SDL_Delay(2000);
    }

    SDL_DestroyTexture(MenuPrincipalTex);
    SDL_DestroyTexture(actual);
    SDL_DestroyTexture(T0);
    SDL_DestroyTexture(T1);
    SDL_DestroyTexture(T2);
    SDL_DestroyTexture(T3);
    SDL_DestroyTexture(T4);
    SDL_DestroyTexture(T5);
    SDL_DestroyTexture(T6);
    SDL_DestroyTexture(T7);
    SDL_FreeSurface(CntosJugadoresSurf);
    SDL_DestroyTexture(CntosJugadoresTex);
    SDL_FreeSurface(MenuPrincipalReglasSurf);
    SDL_DestroyTexture(MenuPrincipalReglasTex);
    SDL_FreeSurface(MenuDeJuegoSurf);
    SDL_DestroyTexture(MenuDeJuegoTex);
    SDL_FreeSurface(AyudaCartas1Surf);
    SDL_DestroyTexture(AyudaCartas1Tex);
    SDL_FreeSurface(AyudaCartas2Surf);
    SDL_DestroyTexture(AyudaCartas2Tex);
    SDL_FreeSurface(MenuManoSurf);
    SDL_DestroyTexture(MenuManoTex);
    SDL_FreeSurface(MenuManoSeleccionSurf);
    SDL_DestroyTexture(MenuManoSeleccionTex);
    SDL_FreeSurface(MenuGuardianSurf);
    SDL_DestroyTexture(MenuGuardianTex);
    SDL_FreeSurface(MenuZonaDescarteSurf);
    SDL_DestroyTexture(MenuZonaDescarteTex);
    SDL_FreeSurface(MenuGanadorRondaSurf);
    SDL_DestroyTexture(MenuGanadorRondaTex);
    SDL_FreeSurface(MenuGanadorPartidaSurf);
    SDL_DestroyTexture(MenuGanadorPartidaTex);
    SDL_FreeSurface(BotonJugador1Surf);
    SDL_DestroyTexture(BotonJugador1Tex);
    SDL_FreeSurface(BotonJugador2Surf);
    SDL_DestroyTexture(BotonJugador2Tex);
    SDL_FreeSurface(BotonJugador3Surf);
    SDL_DestroyTexture(BotonJugador3Tex);
    SDL_FreeSurface(BotonJugador4Surf);
    SDL_DestroyTexture(BotonJugador4Tex);
    SDL_FreeSurface(MenuPrimerJugadorSurf);
    SDL_DestroyTexture(MenuPrimerJugadorTex);
    SDL_FreeSurface(PrimerJugador1Surf);
    SDL_DestroyTexture(PrimerJugador1Tex);
    SDL_FreeSurface(PrimerJugador2Surf);
    SDL_DestroyTexture(PrimerJugador2Tex);
    SDL_FreeSurface(PrimerJugador3Surf);
    SDL_DestroyTexture(PrimerJugador3Tex);
    SDL_FreeSurface(PrimerJugador4Surf);
    SDL_DestroyTexture(PrimerJugador4Tex);




    SDL_FreeSurface(CartaGuardiaSurf);
    SDL_DestroyTexture(CartaGuardiaTex);
    SDL_FreeSurface(CartaSacerdoteSurf);
    SDL_DestroyTexture(CartaSacerdoteTex);
    SDL_FreeSurface(CartaBaronSurf);
    SDL_DestroyTexture(CartaBaronTex);
    SDL_FreeSurface(CartaDoncellaSurf);
    SDL_DestroyTexture(CartaDoncellaTex);
    SDL_FreeSurface(CartaPrincipeSurf);
    SDL_DestroyTexture(CartaPrincipeTex);
    SDL_FreeSurface(CartaReySurf);
    SDL_DestroyTexture(CartaReyTex);
    SDL_FreeSurface(CartaCondesaSurf);
    SDL_DestroyTexture(CartaCondesaTex);
    SDL_FreeSurface(CartaPrincesaSurf);
    SDL_DestroyTexture(CartaPrincesaTex);
    SDL_FreeSurface(CartaDetrasSurf);
    SDL_DestroyTexture(CartaDetrasTex);
    SDL_DestroyTexture(CartaActual1);
    SDL_DestroyTexture(CartaActual2);




    SDL_FreeSurface(icon);
    SDL_FreeSurface(MenuPrincipalSurf);
    SDL_FreeSurface(textSurface);
    TTF_CloseFont(font);
    
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    TTF_Quit();
    SDL_Quit();



return 0;
}
